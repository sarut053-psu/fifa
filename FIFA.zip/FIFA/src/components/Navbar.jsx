// นำเข้า React
import React from "react";

// นำเข้าไฟล์ CSS สำหรับตกแต่ง Navbar
import "./Navbar.css";

// รับ props ชื่อ setPage จาก App.jsx เพื่อใช้เปลี่ยนหน้า
const Navbar = ({ setPage }) => {
  return (
    // div หลักของ Navbar
    <div className="navbar">
      {/* ปุ่มไปหน้า Home */}
      <button onClick={() => setPage("home")}>Home</button>

      {/* ปุ่มไปหน้า Employee */}
      <button onClick={() => setPage("employee")}>Employee</button>
    </div>
  );
};

// ส่งออก Navbar ให้ไฟล์อื่นนำไปใช้งานได้
export default Navbar;
