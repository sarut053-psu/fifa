// นำเข้า React
import React from "react";

// นำเข้า Component Person (เอาไว้แสดงแต่ละคน)
import Person from "./Person";

// รับ props: persons (array ของนักฟุตบอล) และ onSelect (ฟังก์ชันเลือกคน)
const PersonList = ({ persons, onSelect }) => {
  return (
    // div ครอบรายชื่อทั้งหมด
    <div className="person-list">
      {/* วนลูป array persons แล้วสร้าง Person component ทีละตัว */}
      {persons.map((p, index) => (
        // key ใช้ index (ไม่ซ้ำกันในลิสต์) 
        // ส่งข้อมูล person และฟังก์ชัน onSelect ไปให้ Person
        <Person key={index} person={p} onSelect={onSelect} />
      ))}
    </div>
  );
};

// export ออกไปใช้ใน Employee.jsx
export default PersonList;
