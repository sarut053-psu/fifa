// นำเข้า React
import React from "react";

// รับ props: persons (array ของนักฟุตบอล) และ onSelect (ฟังก์ชันเวลาเลือก)
const PersonList = ({ persons, onSelect }) => {
  return (
    // กล่องรายชื่อทั้งหมด (ด้านซ้าย)
    <div 
      className="person-list" 
      style={{ padding: "10px", borderRight: "1px solid #ccc" }}
    >
      {/* ใช้ ul แสดงรายชื่อเป็นลิสต์ */}
      <ul style={{ listStyle: "none", padding: 0 }}>
        {persons.map((person, index) => {
          // ดึง "สโมสรปัจจุบัน" ออกมาจาก detail ของนักฟุตบอล
          // โดยแยกเป็นบรรทัด แล้วหาเฉพาะบรรทัดที่ขึ้นต้นด้วย "สโมสรปัจจุบัน:"
          const clubLine = person.detail
            .split("\n")
            .find((line) => line.startsWith("สโมสรปัจจุบัน:"));

          return (
            // แสดงแต่ละรายชื่อใน
            <li
              key={index} // key ไม่ซ้ำกันสำหรับ React
              style={{ cursor: "pointer", marginBottom: "10px" }} // ให้กดได้ + มีระยะห่าง
              onClick={() => onSelect(person)} // เมื่อคลิกจะส่งข้อมูล person กลับไปที่ Employee.jsx
            >
              {/* ชื่อผู้เล่น */}
              <strong>{person.name}</strong>

              {/* ถ้ามี clubLine ให้แสดงชื่อสโมสร (ตัดคำว่า "สโมสรปัจจุบัน:" ทิ้ง) */}
              {clubLine && (
                <div style={{ fontSize: "0.9em", color: "#555" }}>
                  {clubLine.replace("สโมสรปัจจุบัน:", "").trim()}
                </div>
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
};

// export component ไปใช้งานใน Employee.jsx
export default PersonList;
