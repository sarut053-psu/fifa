// นำเข้า React library
import React from "react";

// นำเข้าไฟล์ CSS สำหรับจัดสไตล์หน้า Home
import "./Home.css";

// นำเข้ารูปภาพจากโฟลเดอร์ assets
import Sui from "../assets/sui.png";

// สร้าง component Home
const Home = () => {
  return (
    // div หลักของหน้า ใช้ class "home" (กำหนดใน Home.css)
    <div className="home">
      
      {/* กล่องการ์ด (Card) แสดงเนื้อหาภายใน */}
      <div className="home-card">
        
        {/* ข้อความหัวข้อ */}
        <h1>SUII !!!</h1>
        
        {/* แทรกรูปภาพที่ import มา พร้อมใส่ alt สำหรับกรณีโหลดไม่ขึ้น */}
        <img src={Sui} alt="Sui" className="home-image" />
        
        {/* ข้อความชื่อผู้จัดทำ */}
        <p>Sarut Wichaidit</p>
      </div>
    </div>
  );
};

// export component ออกไปให้ App.jsx เรียกใช้
export default Home;

