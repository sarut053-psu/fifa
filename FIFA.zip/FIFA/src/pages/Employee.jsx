// นำเข้า React และ useState สำหรับจัดการ state
import React, { useState } from "react";

// นำเข้า component PersonList ที่ไว้แสดงรายชื่อบุคคล
import PersonList from "../components/PersonList";

// นำเข้าไฟล์ CSS สำหรับจัดสไตล์หน้า Employee
import "./Employee.css";

// รับ props "employees" ที่ส่งมาจาก App.jsx
const Employee = ({ employees }) => {
  // state สำหรับเก็บนักฟุตบอลที่ถูกเลือก
  const [selected, setSelected] = useState(null);

  return (
    <div className="employee">
      {/* หัวข้อหน้า */}
      <h2>รายชื่อนักฟุตบอลดัง</h2>

      {/* Container หลัก แบ่งเป็น 2 ส่วน (ซ้าย = รายชื่อ, ขวา = รายละเอียด) */}
      <div className="employee-container">
        
        {/* รายชื่อด้านซ้าย */}
        {/* ส่ง props persons = employees และ onSelect = setSelected ไปให้ PersonList */}
        <PersonList persons={employees} onSelect={setSelected} />
        
        {/* รายละเอียดด้านขวา */}
        <div className="employee-detail">
          {selected ? ( // ถ้ามีการเลือกนักฟุตบอลแล้ว
            <div>
              {/* แสดงชื่อที่เลือก */}
              <h3>{selected.name}</h3>
              {/* แสดงรายละเอียด โดยใช้ whiteSpace: "pre-line" 
                  เพื่อให้ \n ใน string ตัดบรรทัดจริง ๆ */}
              <p style={{ whiteSpace: "pre-line" }}>{selected.detail}</p>
            </div>
          ) : (
            // ถ้ายังไม่ได้เลือกใครเลย
            <p>คลิกที่ชื่อนักฟุตบอลด้านซ้ายเพื่อดูรายละเอียด</p>
          )}
        </div>
      </div>
    </div>
  );
};

// export component Employee ออกไปให้ App.jsx ใช้งาน
export default Employee;
