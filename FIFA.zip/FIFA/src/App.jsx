// นำเข้า React และ hook useState สำหรับจัดการ state
import React, { useState } from "react";

// นำเข้า component Navbar, Home, และ Employee
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import Employee from "./pages/Employee";

// สร้าง component หลักของแอปชื่อ App
const App = () => {
  // สร้าง state ชื่อ page ค่าเริ่มต้นเป็น "home"
  // ใช้สำหรับกำหนดว่าจะให้แสดงหน้าไหน
  const [page, setPage] = useState("home");

  // เก็บข้อมูลนักฟุตบอล (ทำหน้าที่เป็น employee data)
  // เป็น array ของ object โดยแต่ละ object มี name และ detail
  const employees = [
    { 
      name: "Lionel Messi", 
      detail: "ตำแหน่ง: Forward\nค่าตัว: €35M\nสโมสรปัจจุบัน: Inter Miami" 
    },
    { 
      name: "Cristiano Ronaldo", 
      detail: "ตำแหน่ง: Forward\nค่าตัว: €15M\nสโมสรปัจจุบัน: Al Nassr" 
    },
    { 
      name: "Kylian Mbappé", 
      detail: "ตำแหน่ง: Forward\nค่าตัว: €180M\nสโมสรปัจจุบัน: Real Madrid" 
    },
    { 
      name: "Erling Haaland", 
      detail: "ตำแหน่ง: Striker\nค่าตัว: €170M\nสโมสรปัจจุบัน: Manchester City" 
    },
    { 
      name: "Kevin De Bruyne", 
      detail: "ตำแหน่ง: Midfielder\nค่าตัว: €70M\nสโมสรปัจจุบัน: Manchester City" 
    },
  ];

  // ส่วนที่ return UI ที่ต้องการแสดงผล
  return (
    <div>
      {/* Navbar ใช้สำหรับสลับหน้า ส่ง setPage ไปให้เพื่อเปลี่ยน state */}
      <Navbar setPage={setPage} />

      {/* ถ้า page = "home" ให้แสดงหน้า Home */}
      {page === "home" && <Home />}

      {/* ถ้า page = "employee" ให้แสดงหน้า Employee พร้อมส่งข้อมูล employees ไปด้วย */}
      {page === "employee" && <Employee employees={employees} />}
    </div>
  );
};

// export App ออกไปให้ไฟล์อื่นใช้งานได้
export default App;